#pycharm
#flask
#heroku servidor de hospedagem cria conta
#Pasta por padr�o nome templates 
#arquivos:
#homepage.html 
#jurados.html
#alunos.html homepage.html 
#quesitos.html
#notas.html


#no arquivo: app.py

#terminal: 

#pip install flask
#ap�s cria��o do arquivo procfile 
#pip install procfile
#pip install freeze > requirements
#no terminal heroku login
#git config --global user.email "iojordino@gmail.com"
#no terminal git:remote -a nome do site(app) criado no heroku (outro nome n�o funciona)  

from flask import Flask

app = Flask(__name__)


#fun��es

@app.route ("/") #exibir o localhost

def homepage():
	
	return render_template("homepage.html")


@app.route ("/jurados/<nome_jurado>")

	def jurados(nome_jurado):

	return render_template ("jurados.html/nome_jurado",nome_jurado = nome_jurado)


@app.route ("/alunos/<nome_aluno>")

	def alunos(nome_aluno):

	return render_template ("alunos.html/nome_aluno",nome_aluno = nome_aluno) 


@app.route ("/quesitos/<nome_quesito>")

	def quesitos(nome_quesito):

	return render_template ("quesitos.html/nome_requisito",nome_requisito = nome_requisito)


@app.route ("/notas/<nome_nota>")

	def notas(nome_nota):

	return render_template ("alunos.html/nome_nota",nome_nota = nome_nota)
	

#colocar site no ar

if __name__ == "__main__":

app.run(debug=true)

#ap�s novas altera��es utilizar apenas os comandos:
# heroku login 
# comandos abaixo atualizam as altera��es no servidor heroku
# git add .
# git commit -am "nova altera��o como mensagem,exemplo: "deploy inicial"
# git push heroku master (aplica��o no ar) 